import { useState, useCallback, useRef } from "react";
import {
  LayoutDashboard, Users, Package, ShoppingCart, FileText, BarChart3,
  Settings, Bell, LogOut, ChevronRight, Menu, X, Plus, Search, Filter,
  Download, Printer, Edit2, Trash2, Eye, ArrowUpRight, ArrowDownRight,
  TrendingUp, DollarSign, Truck, AlertTriangle, CheckCircle, XCircle,
  Clock, Star, Shield, Zap, Globe, ChevronDown, ChevronUp, MoreVertical,
  Building2, UserCircle, Lock, CreditCard, Percent, Tag, BarChart2,
  Receipt, Wallet, Package2, Layers, RefreshCw, Upload, Home, Mail,
  Phone, MapPin, Check, Minus, Calculator, ScanLine, Banknote,
  PieChart, Activity, ArrowRight, Send, MessageSquare, Info, LogIn,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, PieChart as RechartsPie, Pie, Cell,
} from "recharts";

// ─── TYPES ────────────────────────────────────────────────────────────────────
type AppView = "landing" | "login" | "register" | "forgot" | "app";
type AppRole = "superadmin" | "owner" | "manager" | "cashier" | "accountant";
type AppPage =
  | "dashboard" | "super-dashboard" | "customers" | "suppliers" | "products"
  | "pos" | "purchase" | "inventory" | "reports" | "expenses"
  | "users" | "settings" | "notifications" | "profile";

// ─── MOCK DATA ─────────────────────────────────────────────────────────────────
const salesData = [
  { month: "Jan", sales: 145000, purchases: 89000, profit: 56000 },
  { month: "Feb", sales: 178000, purchases: 102000, profit: 76000 },
  { month: "Mar", sales: 162000, purchases: 95000, profit: 67000 },
  { month: "Apr", sales: 210000, purchases: 118000, profit: 92000 },
  { month: "May", sales: 195000, purchases: 110000, profit: 85000 },
  { month: "Jun", sales: 248000, purchases: 135000, profit: 113000 },
  { month: "Jul", sales: 231000, purchases: 128000, profit: 103000 },
  { month: "Aug", sales: 267000, purchases: 142000, profit: 125000 },
];

const dailySales = [
  { day: "Mon", amount: 18400 }, { day: "Tue", amount: 22100 },
  { day: "Wed", amount: 19800 }, { day: "Thu", amount: 25600 },
  { day: "Fri", amount: 31200 }, { day: "Sat", amount: 28900 }, { day: "Sun", amount: 15400 },
];

const pieData = [
  { name: "Electronics", value: 34, color: "#2563EB" },
  { name: "Clothing", value: 28, color: "#10B981" },
  { name: "Groceries", value: 22, color: "#F59E0B" },
  { name: "Hardware", value: 16, color: "#8B5CF6" },
];

const adminStats = [
  { month: "Jan", businesses: 42, revenue: 520000 },
  { month: "Feb", businesses: 58, revenue: 720000 },
  { month: "Mar", businesses: 71, revenue: 880000 },
  { month: "Apr", businesses: 89, revenue: 1100000 },
  { month: "May", businesses: 104, revenue: 1280000 },
  { month: "Jun", businesses: 128, revenue: 1560000 },
];

const customers = [
  { id: 1, name: "Raj Enterprises", contact: "Rajesh Kumar", phone: "+91 98765 43210", email: "raj@enterprises.in", city: "Mumbai", balance: 45200, status: "Active", invoices: 24 },
  { id: 2, name: "Mehta Traders", contact: "Suresh Mehta", phone: "+91 87654 32109", email: "suresh@mehtatraders.in", city: "Delhi", balance: -8400, status: "Active", invoices: 18 },
  { id: 3, name: "Patel Industries", contact: "Ankit Patel", phone: "+91 76543 21098", email: "ankit@patelindustries.in", city: "Ahmedabad", balance: 12800, status: "Inactive", invoices: 7 },
  { id: 4, name: "Sharma & Sons", contact: "Vikram Sharma", phone: "+91 65432 10987", email: "vikram@sharmasons.in", city: "Jaipur", balance: 0, status: "Active", invoices: 31 },
  { id: 5, name: "Gupta Wholesale", contact: "Ramesh Gupta", phone: "+91 54321 09876", email: "ramesh@guptawholesale.in", city: "Lucknow", balance: 67500, status: "Active", invoices: 42 },
  { id: 6, name: "Singh Distributors", contact: "Harpreet Singh", phone: "+91 43210 98765", email: "hp@singhdist.in", city: "Chandigarh", balance: -2100, status: "Active", invoices: 15 },
];

const suppliers = [
  { id: 1, name: "TechVision Pvt Ltd", contact: "Arun Verma", phone: "+91 98111 22333", email: "arun@techvision.in", city: "Bangalore", balance: 125000, status: "Active" },
  { id: 2, name: "FabWorld Exports", contact: "Priya Joshi", phone: "+91 87222 33444", email: "priya@fabworld.in", city: "Surat", balance: 43000, status: "Active" },
  { id: 3, name: "AgriLink Wholesale", contact: "Mohan Das", phone: "+91 76333 44555", email: "mohan@agrilink.in", city: "Pune", balance: 8900, status: "Active" },
  { id: 4, name: "Metro Hardware Hub", contact: "Deepak Rao", phone: "+91 65444 55666", email: "deepak@metrohardware.in", city: "Hyderabad", balance: 31200, status: "Inactive" },
];

const products = [
  { id: 1, name: "Samsung Galaxy Buds Pro", sku: "EL-SGB-001", category: "Electronics", supplier: "TechVision Pvt Ltd", cost: 4200, price: 6999, stock: 48, minStock: 10, status: "Active" },
  { id: 2, name: "Cotton Linen Shirt (L)", sku: "CL-CLS-002", category: "Clothing", supplier: "FabWorld Exports", cost: 350, price: 899, stock: 134, minStock: 20, status: "Active" },
  { id: 3, name: "Basmati Rice Premium 5kg", sku: "GR-BR5-003", category: "Groceries", supplier: "AgriLink Wholesale", cost: 320, price: 520, stock: 8, minStock: 25, status: "Active" },
  { id: 4, name: "Power Drill 800W Bosch", sku: "HW-PDB-004", category: "Hardware", supplier: "Metro Hardware Hub", cost: 2800, price: 4499, stock: 22, minStock: 5, status: "Active" },
  { id: 5, name: "Wireless Mechanical Keyboard", sku: "EL-WMK-005", category: "Electronics", supplier: "TechVision Pvt Ltd", cost: 1800, price: 3299, stock: 0, minStock: 8, status: "Inactive" },
  { id: 6, name: "Denim Jeans Slim Fit (32)", sku: "CL-DJS-006", category: "Clothing", supplier: "FabWorld Exports", cost: 650, price: 1499, stock: 76, minStock: 15, status: "Active" },
  { id: 7, name: "Olive Oil Extra Virgin 1L", sku: "GR-OOE-007", category: "Groceries", supplier: "AgriLink Wholesale", cost: 280, price: 450, stock: 61, minStock: 30, status: "Active" },
];

const invoices = [
  { id: "INV-2024-1042", customer: "Raj Enterprises", date: "2024-08-14", amount: 28750, gst: 5175, total: 33925, status: "Paid", due: "2024-08-28" },
  { id: "INV-2024-1041", customer: "Mehta Traders", date: "2024-08-13", amount: 12400, gst: 2232, total: 14632, status: "Pending", due: "2024-08-27" },
  { id: "INV-2024-1040", customer: "Gupta Wholesale", date: "2024-08-12", amount: 67800, gst: 12204, total: 80004, status: "Paid", due: "2024-08-26" },
  { id: "INV-2024-1039", customer: "Sharma & Sons", date: "2024-08-11", amount: 5600, gst: 1008, total: 6608, status: "Overdue", due: "2024-08-18" },
  { id: "INV-2024-1038", customer: "Singh Distributors", date: "2024-08-10", amount: 19200, gst: 3456, total: 22656, status: "Paid", due: "2024-08-24" },
];

const expenses = [
  { id: 1, category: "Rent", description: "Office & Warehouse Rent - August", date: "2024-08-01", amount: 45000, paymentMode: "Bank Transfer", status: "Paid" },
  { id: 2, category: "Utilities", description: "Electricity & Internet Bills", date: "2024-08-05", amount: 8200, paymentMode: "UPI", status: "Paid" },
  { id: 3, category: "Salaries", description: "Staff Salaries - August", date: "2024-08-07", amount: 125000, paymentMode: "Bank Transfer", status: "Paid" },
  { id: 4, category: "Marketing", description: "Google Ads Campaign", date: "2024-08-10", amount: 15000, paymentMode: "Credit Card", status: "Paid" },
  { id: 5, category: "Logistics", description: "Delivery & Transport Costs", date: "2024-08-12", amount: 12400, paymentMode: "Cash", status: "Pending" },
];

const employees = [
  { id: 1, name: "Priya Sharma", email: "priya@business.in", role: "Manager", department: "Operations", lastActive: "2 mins ago", status: "Active" },
  { id: 2, name: "Arjun Nair", email: "arjun@business.in", role: "Cashier", department: "Sales", lastActive: "1 hour ago", status: "Active" },
  { id: 3, name: "Kavita Reddy", email: "kavita@business.in", role: "Accountant", department: "Finance", lastActive: "Yesterday", status: "Active" },
  { id: 4, name: "Rahul Mishra", email: "rahul@business.in", role: "Cashier", department: "Sales", lastActive: "3 days ago", status: "Inactive" },
];

const notifications = [
  { id: 1, type: "warning", title: "Low Stock Alert", message: "Basmati Rice Premium 5kg has only 8 units remaining (Min: 25)", time: "10 mins ago", read: false },
  { id: 2, type: "error", title: "Payment Overdue", message: "Invoice INV-2024-1039 from Sharma & Sons is overdue by 3 days", time: "1 hour ago", read: false },
  { id: 3, type: "success", title: "Payment Received", message: "₹33,925 received from Raj Enterprises for INV-2024-1042", time: "3 hours ago", read: true },
  { id: 4, type: "info", title: "System Update", message: "BillTrack Pro v3.2.1 is now available with new GST features", time: "Yesterday", read: true },
  { id: 5, type: "warning", title: "Low Stock Alert", message: "Wireless Mechanical Keyboard is out of stock", time: "Yesterday", read: true },
];

const businesses = [
  { id: 1, name: "Sharma Electronics", owner: "Vikram Sharma", plan: "Pro", users: 8, revenue: 245000, status: "Active", joined: "2024-03-15" },
  { id: 2, name: "Mumbai Textiles", owner: "Nirmala Patel", plan: "Enterprise", users: 24, revenue: 1280000, status: "Active", joined: "2024-01-22" },
  { id: 3, name: "Delhi Grocers", owner: "Amar Singh", plan: "Starter", users: 3, revenue: 89000, status: "Active", joined: "2024-06-08" },
  { id: 4, name: "Pune Hardware Hub", owner: "Sanjay More", plan: "Pro", users: 6, revenue: 412000, status: "Suspended", joined: "2024-02-14" },
  { id: 5, name: "Chennai Pharma", owner: "Lakshmi Rajan", plan: "Enterprise", users: 31, revenue: 2100000, status: "Active", joined: "2023-11-30" },
];

const posProducts = products.filter(p => p.stock > 0 && p.status === "Active");

const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;
const fmtK = (n: number) => n >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : n >= 1000 ? `₹${(n / 1000).toFixed(1)}K` : `₹${n}`;

// ─── DESIGN SYSTEM ─────────────────────────────────────────────────────────────

type BtnVariant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "success";
type BtnSize = "sm" | "md" | "lg";

function Btn({
  children, variant = "primary", size = "md", onClick, className = "", disabled = false, icon,
}: {
  children?: React.ReactNode; variant?: BtnVariant; size?: BtnSize;
  onClick?: () => void; className?: string; disabled?: boolean;
  icon?: React.ReactNode;
}) {
  const base = "inline-flex items-center gap-2 font-medium rounded-lg transition-all duration-150 cursor-pointer select-none";
  const sizes = { sm: "px-3 py-1.5 text-xs", md: "px-4 py-2 text-sm", lg: "px-6 py-2.5 text-sm" };
  const variants = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 shadow-sm active:scale-[0.98]",
    secondary: "bg-slate-100 text-slate-700 hover:bg-slate-200 active:scale-[0.98]",
    outline: "border border-slate-300 text-slate-700 hover:bg-slate-50 active:scale-[0.98]",
    ghost: "text-slate-600 hover:bg-slate-100 active:scale-[0.98]",
    danger: "bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 active:scale-[0.98]",
    success: "bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm active:scale-[0.98]",
  };
  return (
    <button onClick={onClick} disabled={disabled} className={`${base} ${sizes[size]} ${variants[variant]} ${disabled ? "opacity-50 cursor-not-allowed" : ""} ${className}`}>
      {icon && icon}{children}
    </button>
  );
}

type BadgeVariant = "blue" | "green" | "yellow" | "red" | "gray" | "purple";
function Badge({ label, variant = "gray" }: { label: string; variant?: BadgeVariant }) {
  const v: Record<BadgeVariant, string> = {
    blue: "bg-blue-50 text-blue-700 border border-blue-200",
    green: "bg-emerald-50 text-emerald-700 border border-emerald-200",
    yellow: "bg-amber-50 text-amber-700 border border-amber-200",
    red: "bg-red-50 text-red-700 border border-red-200",
    gray: "bg-slate-100 text-slate-600 border border-slate-200",
    purple: "bg-purple-50 text-purple-700 border border-purple-200",
  };
  return <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${v[variant]}`}>{label}</span>;
}

function statusBadge(status: string) {
  const map: Record<string, BadgeVariant> = {
    Active: "green", Inactive: "gray", Paid: "green", Pending: "yellow",
    Overdue: "red", Received: "green", Suspended: "red", Pro: "blue", Enterprise: "purple", Starter: "gray",
  };
  return <Badge label={status} variant={map[status] ?? "gray"} />;
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`bg-white rounded-xl border border-slate-200 shadow-sm ${className}`}>{children}</div>;
}

function Input({
  label, value, onChange, placeholder = "", type = "text", icon,
}: {
  label?: string; value?: string; onChange?: (v: string) => void;
  placeholder?: string; type?: string; icon?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{label}</label>}
      <div className="relative">
        {icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">{icon}</span>}
        <input
          type={type}
          value={value}
          onChange={e => onChange?.(e.target.value)}
          placeholder={placeholder}
          className={`w-full border border-slate-200 rounded-lg bg-white text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all py-2.5 ${icon ? "pl-9 pr-3" : "px-3"}`}
        />
      </div>
    </div>
  );
}

function Select({ label, value, onChange, options }: {
  label?: string; value: string; onChange: (v: string) => void; options: string[];
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{label}</label>}
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        className="border border-slate-200 rounded-lg bg-white text-sm text-slate-900 px-3 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      >
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

function StatCard({
  label, value, sub, trend, icon, color,
}: {
  label: string; value: string; sub: string; trend?: "up" | "down" | "neutral";
  icon: React.ReactNode; color: string;
}) {
  return (
    <Card className="p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          {icon}
        </div>
        {trend && (
          <span className={`flex items-center gap-1 text-xs font-medium ${trend === "up" ? "text-emerald-600" : trend === "down" ? "text-red-500" : "text-slate-500"}`}>
            {trend === "up" ? <ArrowUpRight className="w-3 h-3" /> : trend === "down" ? <ArrowDownRight className="w-3 h-3" /> : null}
            {sub}
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-slate-900 mb-1">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </Card>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5">{children}</div>
      </Card>
    </div>
  );
}

function ConfirmDialog({ message, onConfirm, onCancel }: { message: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <Card className="w-full max-w-sm">
        <div className="p-6 text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-6 h-6 text-red-500" />
          </div>
          <h3 className="font-semibold text-slate-900 mb-2">Are you sure?</h3>
          <p className="text-sm text-slate-500 mb-5">{message}</p>
          <div className="flex gap-3">
            <Btn variant="outline" onClick={onCancel} className="flex-1">Cancel</Btn>
            <Btn variant="danger" onClick={onConfirm} className="flex-1 bg-red-600 text-white hover:bg-red-700 border-0">Delete</Btn>
          </div>
        </div>
      </Card>
    </div>
  );
}

function EmptyState({ icon, title, sub, action }: { icon: React.ReactNode; title: string; sub: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mb-4 text-slate-400">{icon}</div>
      <h3 className="font-semibold text-slate-700 mb-1">{title}</h3>
      <p className="text-sm text-slate-500 mb-4 max-w-xs">{sub}</p>
      {action}
    </div>
  );
}

function Toast({ message, type, onClose }: { message: string; type: "success" | "error" | "info"; onClose: () => void }) {
  const colors = { success: "bg-emerald-600", error: "bg-red-500", info: "bg-blue-600" };
  return (
    <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-xl text-white text-sm font-medium shadow-xl ${colors[type]}`}>
      {type === "success" && <CheckCircle className="w-4 h-4" />}
      {type === "error" && <XCircle className="w-4 h-4" />}
      {type === "info" && <Info className="w-4 h-4" />}
      {message}
      <button onClick={onClose}><X className="w-4 h-4 opacity-70 hover:opacity-100" /></button>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────

const NAV_GROUPS = [
  {
    label: "Main",
    items: [
      { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    ],
  },
  {
    label: "Commerce",
    items: [
      { key: "customers", label: "Customers", icon: Users },
      { key: "suppliers", label: "Suppliers", icon: Truck },
      { key: "products", label: "Products", icon: Package },
    ],
  },
  {
    label: "Transactions",
    items: [
      { key: "pos", label: "Sales / Billing", icon: Receipt },
      { key: "purchase", label: "Purchase", icon: ShoppingCart },
      { key: "inventory", label: "Inventory", icon: Layers },
      { key: "expenses", label: "Expenses", icon: Wallet },
    ],
  },
  {
    label: "Insights",
    items: [
      { key: "reports", label: "Reports", icon: BarChart3 },
    ],
  },
  {
    label: "Administration",
    items: [
      { key: "users", label: "Users", icon: Shield },
      { key: "settings", label: "Settings", icon: Settings },
    ],
  },
];

const SUPER_ADMIN_ITEMS = [
  { key: "super-dashboard", label: "Overview", icon: LayoutDashboard },
  { key: "customers", label: "Businesses", icon: Building2 },
  { key: "users", label: "Users", icon: Users },
  { key: "reports", label: "Revenue", icon: BarChart3 },
  { key: "settings", label: "Settings", icon: Settings },
];

function Sidebar({
  page, onNav, role, collapsed, onToggle,
}: {
  page: AppPage; onNav: (p: AppPage) => void; role: AppRole;
  collapsed: boolean; onToggle: () => void;
}) {
  const isSuperAdmin = role === "superadmin";

  return (
    <aside
      className="flex flex-col bg-slate-900 transition-all duration-300 z-20 flex-shrink-0"
      style={{ width: collapsed ? 64 : 240 }}
    >
      {/* Logo */}
      <div className={`flex items-center border-b border-slate-800 h-16 px-4 gap-3 flex-shrink-0`}>
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
          <BarChart2 className="w-4 h-4 text-white" />
        </div>
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-white truncate">BillTrack Pro</p>
            <p className="text-[10px] text-slate-500 capitalize">{role.replace("-", " ")}</p>
          </div>
        )}
        <button onClick={onToggle} className="text-slate-500 hover:text-slate-300 transition-colors flex-shrink-0">
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 overflow-y-auto overflow-x-hidden">
        {isSuperAdmin ? (
          <div className="space-y-0.5 px-3">
            {SUPER_ADMIN_ITEMS.map(({ key, label, icon: Icon }) => {
              const active = page === key;
              return (
                <button
                  key={key}
                  onClick={() => onNav(key as AppPage)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group relative ${active ? "bg-blue-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  {!collapsed && <span>{label}</span>}
                  {collapsed && (
                    <span className="absolute left-14 bg-slate-800 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-50 shadow-xl">
                      {label}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="space-y-5">
            {NAV_GROUPS.map(group => (
              <div key={group.label}>
                {!collapsed && (
                  <p className="px-6 mb-1 text-[10px] font-semibold text-slate-600 uppercase tracking-widest">{group.label}</p>
                )}
                <div className="space-y-0.5 px-3">
                  {group.items.map(({ key, label, icon: Icon }) => {
                    const active = page === key;
                    return (
                      <button
                        key={key}
                        onClick={() => onNav(key as AppPage)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group relative ${active ? "bg-blue-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        {!collapsed && <span>{label}</span>}
                        {collapsed && (
                          <span className="absolute left-14 bg-slate-800 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-50 shadow-xl">
                            {label}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </nav>

      {/* User */}
      <div className="border-t border-slate-800 p-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600/20 rounded-full flex items-center justify-center flex-shrink-0">
            <UserCircle className="w-4 h-4 text-blue-400" />
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-white truncate">Admin User</p>
              <p className="text-[10px] text-slate-500 truncate">admin@business.in</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}

// ─── TOPBAR ───────────────────────────────────────────────────────────────────

const PAGE_LABELS: Record<AppPage, string> = {
  "dashboard": "Dashboard", "super-dashboard": "Admin Overview",
  "customers": "Customers", "suppliers": "Suppliers", "products": "Products",
  "pos": "Sales & Billing", "purchase": "Purchase", "inventory": "Inventory",
  "reports": "Reports", "expenses": "Expenses", "users": "User Management",
  "settings": "Business Settings", "notifications": "Notifications", "profile": "Profile",
};

function Topbar({
  page, onLogout, onNav, role, notifCount,
}: {
  page: AppPage; onLogout: () => void; onNav: (p: AppPage) => void;
  role: AppRole; notifCount: number;
}) {
  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center px-6 gap-4 flex-shrink-0">
      <div className="flex-1">
        <h1 className="text-base font-semibold text-slate-900">{PAGE_LABELS[page]}</h1>
        <p className="text-xs text-slate-500">
          {new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
        </p>
      </div>

      <div className="flex items-center gap-1 bg-slate-100 rounded-lg px-3 py-2 text-slate-500 text-xs w-52 border border-slate-200">
        <Search className="w-3.5 h-3.5 mr-1.5" />
        Search anything...
        <kbd className="ml-auto text-[10px] bg-slate-200 px-1.5 py-0.5 rounded">⌘K</kbd>
      </div>

      {role === "owner" && (
        <Btn variant="primary" size="sm" onClick={() => onNav("pos")} icon={<Plus className="w-3.5 h-3.5" />}>
          New Invoice
        </Btn>
      )}

      <button
        onClick={() => onNav("notifications")}
        className="relative w-9 h-9 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
      >
        <Bell className="w-4.5 h-4.5" />
        {notifCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
            {notifCount}
          </span>
        )}
      </button>

      <div className="flex items-center gap-2 pl-3 border-l border-slate-200">
        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
          <span className="text-xs font-bold text-white">AU</span>
        </div>
        <div className="hidden sm:block">
          <p className="text-xs font-semibold text-slate-800">Admin User</p>
          <p className="text-[10px] text-slate-500 capitalize">{role}</p>
        </div>
        <button onClick={onLogout} className="ml-1 text-slate-400 hover:text-red-500 transition-colors">
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}

// ─── LANDING PAGE ─────────────────────────────────────────────────────────────

const FEATURES = [
  { icon: Receipt, title: "Smart Invoicing", desc: "Generate GST-compliant invoices in seconds with customizable templates and auto-calculations.", color: "bg-blue-50 text-blue-600" },
  { icon: Package2, title: "Inventory Management", desc: "Track stock in real-time with low-stock alerts, barcode scanning, and batch management.", color: "bg-emerald-50 text-emerald-600" },
  { icon: BarChart3, title: "Advanced Reports", desc: "P&L statements, GST reports, and 20+ business analytics with Excel/PDF export.", color: "bg-purple-50 text-purple-600" },
  { icon: Users, title: "Multi-User Access", desc: "Role-based access control for Owner, Manager, Cashier, and Accountant profiles.", color: "bg-amber-50 text-amber-600" },
  { icon: Globe, title: "Cloud-Based", desc: "Access your business data from anywhere, anytime on any device.", color: "bg-rose-50 text-rose-600" },
  { icon: Shield, title: "Bank-Grade Security", desc: "256-bit SSL encryption, daily backups, and SOC 2 compliant infrastructure.", color: "bg-slate-100 text-slate-600" },
];

const PLANS = [
  {
    name: "Starter", price: 999, period: "/month", color: "border-slate-200", badge: null,
    features: ["1 Business", "2 Users", "500 Invoices/month", "Basic Reports", "Email Support"],
  },
  {
    name: "Pro", price: 2499, period: "/month", color: "border-blue-500", badge: "Most Popular",
    features: ["3 Businesses", "10 Users", "Unlimited Invoices", "Advanced Reports", "GST Filing", "Priority Support", "Barcode Scanner"],
  },
  {
    name: "Enterprise", price: 6999, period: "/month", color: "border-slate-200", badge: null,
    features: ["Unlimited Businesses", "Unlimited Users", "Everything in Pro", "Custom Integrations", "Dedicated Manager", "SLA Guarantee", "API Access"],
  },
];

const TESTIMONIALS = [
  { name: "Vikram Sharma", role: "Owner, Sharma Electronics, Mumbai", text: "BillTrack Pro transformed how we manage inventory. We reduced stockouts by 80% and invoice errors are practically zero.", avatar: "VS", rating: 5 },
  { name: "Nirmala Patel", role: "MD, Mumbai Textiles", text: "The GST reports alone saved us 30 hours a month. Our accountant loves the automatic reconciliation feature.", avatar: "NP", rating: 5 },
  { name: "Amar Singh", role: "Proprietor, Delhi Grocers", text: "Switched from Tally and never looked back. The mobile-friendly POS is a game changer for our retail operations.", avatar: "AS", rating: 5 },
];

function LandingPage({ onNav }: { onNav: (v: AppView) => void }) {
  const [mobileMenu, setMobileMenu] = useState(false);

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Navbar */}
      <nav className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center gap-8">
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <BarChart2 className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-slate-900">BillTrack Pro</span>
          </div>
          <div className="hidden md:flex items-center gap-6 flex-1">
            {["Features", "Pricing", "Testimonials", "Contact"].map(l => (
              <a key={l} href={`#${l.toLowerCase()}`} className="text-sm text-slate-600 hover:text-blue-600 transition-colors font-medium">{l}</a>
            ))}
          </div>
          <div className="hidden md:flex items-center gap-3 flex-shrink-0">
            <Btn variant="ghost" onClick={() => onNav("login")}>Sign In</Btn>
            <Btn variant="primary" onClick={() => onNav("register")}>Start Free Trial</Btn>
          </div>
          <button onClick={() => setMobileMenu(v => !v)} className="md:hidden ml-auto text-slate-600">
            {mobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        {mobileMenu && (
          <div className="md:hidden border-t border-slate-100 px-6 py-4 space-y-3 bg-white">
            {["Features", "Pricing", "Testimonials"].map(l => (
              <a key={l} href={`#${l.toLowerCase()}`} className="block text-sm text-slate-700 py-1.5">{l}</a>
            ))}
            <div className="flex gap-3 pt-2">
              <Btn variant="outline" onClick={() => onNav("login")} className="flex-1">Sign In</Btn>
              <Btn variant="primary" onClick={() => onNav("register")} className="flex-1">Try Free</Btn>
            </div>
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="bg-gradient-to-b from-slate-50 to-white pt-20 pb-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-full px-4 py-1.5 text-xs text-blue-700 font-medium mb-6">
              <Zap className="w-3 h-3" /> India's #1 Billing & Inventory Platform — Trusted by 50,000+ businesses
            </div>
            <h1 className="text-5xl font-extrabold text-slate-900 leading-tight mb-5">
              Run your entire business<br />
              <span className="text-blue-600">smarter & faster</span>
            </h1>
            <p className="text-lg text-slate-500 leading-relaxed mb-8 max-w-2xl mx-auto">
              Invoicing, inventory, GST filing, purchase orders, and financial reports — everything your business needs in one powerful platform.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Btn variant="primary" size="lg" onClick={() => onNav("register")} icon={<ArrowRight className="w-4 h-4" />}>
                Start 14-Day Free Trial
              </Btn>
              <Btn variant="outline" size="lg" onClick={() => onNav("login")}>
                View Live Demo
              </Btn>
            </div>
            <p className="text-xs text-slate-400 mt-4">No credit card required · Cancel anytime</p>
          </div>

          {/* Hero Screenshot */}
          <div className="relative max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
              <div className="h-8 bg-slate-100 border-b border-slate-200 flex items-center gap-2 px-4">
                <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-red-400" /><div className="w-3 h-3 rounded-full bg-yellow-400" /><div className="w-3 h-3 rounded-full bg-green-400" /></div>
                <div className="flex-1 bg-white rounded border border-slate-200 h-4 mx-4 flex items-center px-2"><span className="text-[9px] text-slate-400">app.billtrackpro.in/dashboard</span></div>
              </div>
              <div className="flex h-72 bg-slate-50">
                <div className="w-40 bg-slate-900 flex flex-col py-3 gap-1 px-2">
                  {["Dashboard","Customers","Products","Billing","Reports"].map((l,i) => (
                    <div key={l} className={`flex items-center gap-2 px-2 py-1.5 rounded text-[10px] ${i===0?"bg-blue-600 text-white":"text-slate-400"}`}>
                      <div className="w-1.5 h-1.5 rounded-full bg-current opacity-60" />{l}
                    </div>
                  ))}
                </div>
                <div className="flex-1 p-4 space-y-3">
                  <div className="grid grid-cols-4 gap-2">
                    {[["₹8.9L","Today's Sales"],["₹2.4L","Pending"],["231","Products"],["42","Customers"]].map(([v,l])=>(
                      <div key={l} className="bg-white rounded-lg border border-slate-200 p-2">
                        <p className="text-sm font-bold text-slate-900">{v}</p>
                        <p className="text-[9px] text-slate-500">{l}</p>
                      </div>
                    ))}
                  </div>
                  <div className="bg-white rounded-lg border border-slate-200 p-3 flex-1">
                    <div className="text-[10px] font-semibold text-slate-600 mb-2">Sales Analytics — Last 8 months</div>
                    <div className="flex items-end gap-1 h-16">
                      {[40,58,48,70,62,82,74,90].map((h,i)=>(
                        <div key={i} className="flex-1 bg-blue-500 rounded-t opacity-80" style={{height:`${h}%`}} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="py-10 border-y border-slate-100 bg-white">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <p className="text-xs text-slate-400 uppercase tracking-widest mb-6">Trusted by leading businesses across India</p>
          <div className="flex flex-wrap justify-center gap-8 items-center">
            {["Sharma Electronics", "Mumbai Textiles", "Delhi Grocers", "Chennai Pharma", "Pune Hardware"].map(b => (
              <span key={b} className="text-sm font-semibold text-slate-400">{b}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs text-blue-600 font-semibold uppercase tracking-widest mb-3">Features</p>
            <h2 className="text-3xl font-extrabold text-slate-900 mb-3">Everything you need to run your business</h2>
            <p className="text-slate-500 max-w-xl mx-auto">Powerful tools built for Indian businesses — from solo traders to enterprise chains.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map(f => (
              <Card key={f.title} className="p-6 hover:shadow-md transition-all hover:-translate-y-0.5">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${f.color}`}>
                  <f.icon className="w-5 h-5" />
                </div>
                <h3 className="font-semibold text-slate-900 mb-2">{f.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{f.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-6 bg-slate-50">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs text-blue-600 font-semibold uppercase tracking-widest mb-3">Pricing</p>
            <h2 className="text-3xl font-extrabold text-slate-900 mb-3">Simple, transparent pricing</h2>
            <p className="text-slate-500">Start free for 14 days. No credit card required.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PLANS.map(plan => (
              <div key={plan.name} className={`bg-white rounded-2xl border-2 p-8 relative ${plan.color} ${plan.badge ? "shadow-lg shadow-blue-100" : ""}`}>
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold px-4 py-1 rounded-full">{plan.badge}</div>
                )}
                <h3 className="font-bold text-slate-900 mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-5">
                  <span className="text-3xl font-extrabold text-slate-900">₹{plan.price.toLocaleString()}</span>
                  <span className="text-slate-500 text-sm">{plan.period}</span>
                </div>
                <ul className="space-y-2.5 mb-7">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-slate-600">
                      <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />{f}
                    </li>
                  ))}
                </ul>
                <Btn
                  variant={plan.badge ? "primary" : "outline"}
                  onClick={() => onNav("register")}
                  className="w-full justify-center"
                >
                  Get Started
                </Btn>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 px-6 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs text-blue-600 font-semibold uppercase tracking-widest mb-3">Testimonials</p>
            <h2 className="text-3xl font-extrabold text-slate-900">What our customers say</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map(t => (
              <Card key={t.name} className="p-6">
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: t.rating }).map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />)}
                </div>
                <p className="text-sm text-slate-600 leading-relaxed mb-5 italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-white">{t.avatar}</span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-blue-600">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-white mb-4">Ready to transform your business?</h2>
          <p className="text-blue-100 mb-8">Join 50,000+ businesses already using BillTrack Pro.</p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Btn variant="secondary" size="lg" onClick={() => onNav("register")}>Start Free Trial</Btn>
            <button className="text-blue-200 hover:text-white text-sm font-medium transition-colors flex items-center gap-2">
              <Phone className="w-4 h-4" /> Talk to Sales
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-slate-900 text-slate-400 py-12 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center"><BarChart2 className="w-3.5 h-3.5 text-white" /></div>
              <span className="font-bold text-white text-sm">BillTrack Pro</span>
            </div>
            <p className="text-xs leading-relaxed">India's most trusted billing and inventory management platform.</p>
          </div>
          {[["Product",["Features","Pricing","Changelog","Roadmap"]],["Company",["About","Blog","Careers","Press"]],["Support",["Help Center","API Docs","Status","Contact"]]].map(([t, links]) => (
            <div key={t as string}>
              <p className="text-xs font-semibold text-white uppercase tracking-wider mb-4">{t as string}</p>
              <ul className="space-y-2">
                {(links as string[]).map(l => <li key={l}><a href="#" className="text-xs hover:text-white transition-colors">{l}</a></li>)}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row justify-between items-center gap-2">
          <p className="text-xs">© 2024 BillTrack Pro. All rights reserved.</p>
          <p className="text-xs">Made with ♥ in India</p>
        </div>
      </footer>
    </div>
  );
}

// ─── AUTH SCREENS ─────────────────────────────────────────────────────────────

function AuthScreen({ view, onNav, onLogin }: {
  view: "login" | "register" | "forgot"; onNav: (v: AppView) => void; onLogin: (role: AppRole) => void;
}) {
  const [role, setRole] = useState<AppRole>("owner");
  const [email, setEmail] = useState(view === "login" ? "admin@business.in" : "");
  const [password, setPassword] = useState(view === "login" ? "password123" : "");
  const [biz, setBiz] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); if (view === "login") onLogin(role); }, 900);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Left panel */}
      <div className="hidden lg:flex flex-col w-[480px] flex-shrink-0 bg-slate-900 relative overflow-hidden p-10">
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, white 1px, transparent 0)", backgroundSize: "28px 28px" }} />
        <div className="flex items-center gap-2.5 mb-auto relative">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center"><BarChart2 className="w-4 h-4 text-white" /></div>
          <span className="font-bold text-white">BillTrack Pro</span>
        </div>
        <div className="relative">
          <div className="inline-flex items-center gap-2 bg-blue-600/20 border border-blue-500/30 rounded-full px-4 py-1.5 mb-6">
            <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
            <span className="text-xs text-blue-300 font-medium">Trusted by 50,000+ businesses</span>
          </div>
          <h2 className="text-3xl font-extrabold text-white leading-snug mb-4">
            Manage your business<br />with confidence
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-8">
            Complete billing, inventory, and accounting in one platform. GST-ready, cloud-based, and built for India.
          </p>
          <div className="space-y-3">
            {["100% GST Compliant invoicing","Real-time inventory tracking","Profit & Loss statements","Multi-user role access"].map(f => (
              <div key={f} className="flex items-center gap-3 text-sm text-slate-300">
                <div className="w-5 h-5 bg-emerald-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-emerald-400" />
                </div>
                {f}
              </div>
            ))}
          </div>
        </div>
        <p className="text-xs text-slate-600 mt-10 relative">© 2024 BillTrack Pro · Privacy · Terms</p>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <button onClick={() => onNav("landing")} className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-blue-600 mb-8 transition-colors">
            <ArrowRight className="w-3 h-3 rotate-180" /> Back to home
          </button>

          {view === "login" && (
            <>
              <h2 className="text-2xl font-bold text-slate-900 mb-1">Welcome back</h2>
              <p className="text-sm text-slate-500 mb-6">Sign in to your BillTrack account</p>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-1.5">Login As</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["owner","superadmin"] as AppRole[]).map(r => (
                      <button key={r} onClick={() => setRole(r)}
                        className={`px-3 py-2 rounded-lg border text-xs font-medium transition-all capitalize ${role===r?"border-blue-500 bg-blue-50 text-blue-700":"border-slate-200 text-slate-600 hover:border-slate-300"}`}>
                        {r === "superadmin" ? "Super Admin" : "Business Owner"}
                      </button>
                    ))}
                  </div>
                </div>
                <Input label="Email Address" value={email} onChange={setEmail} placeholder="you@business.in" icon={<Mail className="w-4 h-4" />} />
                <Input label="Password" type="password" value={password} onChange={setPassword} placeholder="••••••••" icon={<Lock className="w-4 h-4" />} />
                <div className="flex justify-between items-center text-xs">
                  <label className="flex items-center gap-2 text-slate-600 cursor-pointer"><input type="checkbox" defaultChecked className="accent-blue-600" />Remember me</label>
                  <button onClick={() => onNav("forgot")} className="text-blue-600 hover:underline">Forgot password?</button>
                </div>
                <Btn variant="primary" size="lg" onClick={handleSubmit} className="w-full justify-center" icon={loading ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <LogIn className="w-4 h-4" />}>
                  {loading ? "Signing in..." : "Sign In"}
                </Btn>
              </div>
              <p className="text-xs text-center text-slate-500 mt-5">
                Don't have an account? <button onClick={() => onNav("register")} className="text-blue-600 font-medium hover:underline">Register Business</button>
              </p>
            </>
          )}

          {view === "register" && (
            <>
              <h2 className="text-2xl font-bold text-slate-900 mb-1">Create your account</h2>
              <p className="text-sm text-slate-500 mb-6">Start your 14-day free trial. No credit card needed.</p>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <Input label="First Name" placeholder="Rajesh" />
                  <Input label="Last Name" placeholder="Kumar" />
                </div>
                <Input label="Business Name" value={biz} onChange={setBiz} placeholder="Sharma Traders" icon={<Building2 className="w-4 h-4" />} />
                <Input label="Email" value={email} onChange={setEmail} placeholder="you@business.in" icon={<Mail className="w-4 h-4" />} />
                <Input label="Phone" placeholder="+91 98765 43210" icon={<Phone className="w-4 h-4" />} />
                <Input label="Password" type="password" value={password} onChange={setPassword} placeholder="Min. 8 characters" icon={<Lock className="w-4 h-4" />} />
                <Select label="Business Type" value="Retail" onChange={() => {}} options={["Retail","Wholesale","Manufacturing","Services","Distribution"]} />
                <Btn variant="primary" size="lg" onClick={handleSubmit} className="w-full justify-center" icon={loading ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : undefined}>
                  {loading ? "Creating account..." : "Create Account"}
                </Btn>
                <p className="text-[10px] text-slate-400 text-center">By registering, you agree to our Terms of Service and Privacy Policy</p>
              </div>
              <p className="text-xs text-center text-slate-500 mt-4">
                Already registered? <button onClick={() => onNav("login")} className="text-blue-600 font-medium hover:underline">Sign In</button>
              </p>
            </>
          )}

          {view === "forgot" && (
            <>
              <h2 className="text-2xl font-bold text-slate-900 mb-1">Reset your password</h2>
              <p className="text-sm text-slate-500 mb-6">Enter your email and we'll send a reset link.</p>
              {sent ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 text-center">
                  <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
                  <p className="font-semibold text-slate-900 mb-1">Check your email</p>
                  <p className="text-sm text-slate-500">We sent a password reset link to {email}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <Input label="Email Address" value={email} onChange={setEmail} placeholder="you@business.in" icon={<Mail className="w-4 h-4" />} />
                  <Btn variant="primary" size="lg" onClick={() => setSent(true)} className="w-full justify-center" icon={<Send className="w-4 h-4" />}>
                    Send Reset Link
                  </Btn>
                </div>
              )}
              <p className="text-xs text-center text-slate-500 mt-4">
                <button onClick={() => onNav("login")} className="text-blue-600 font-medium hover:underline">← Back to Sign In</button>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── SUPER ADMIN DASHBOARD ────────────────────────────────────────────────────

function SuperAdminDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Businesses" value="1,248" sub="+12% this month" trend="up" icon={<Building2 className="w-5 h-5" />} color="bg-blue-50 text-blue-600" />
        <StatCard label="Total Users" value="8,432" sub="+8.4% this month" trend="up" icon={<Users className="w-5 h-5" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="Active Subscriptions" value="1,104" sub="88.4% of total" trend="up" icon={<CreditCard className="w-5 h-5" />} color="bg-purple-50 text-purple-600" />
        <StatCard label="MRR" value="₹28.4L" sub="+21% this month" trend="up" icon={<DollarSign className="w-5 h-5" />} color="bg-amber-50 text-amber-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-semibold text-slate-900">Revenue Analytics</h3>
              <p className="text-xs text-slate-500 mt-0.5">Monthly recurring revenue</p>
            </div>
            <div className="flex items-center gap-2">
              {["3M","6M","1Y"].map(t => (
                <button key={t} className={`text-xs px-2.5 py-1 rounded-lg ${t==="6M"?"bg-blue-600 text-white":"text-slate-500 hover:bg-slate-100"}`}>{t}</button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={adminStats}>
              <defs>
                <linearGradient id="adminGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/100000).toFixed(1)}L`} />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, "Revenue"]} />
              <Area type="monotone" dataKey="revenue" stroke="#2563EB" strokeWidth={2.5} fill="url(#adminGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 mb-5">Plan Distribution</h3>
          <ResponsiveContainer width="100%" height={180}>
            <RechartsPie>
              <Pie data={[{name:"Starter",value:480},{name:"Pro",value:512},{name:"Enterprise",value:256}]} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                {["#CBD5E1","#2563EB","#7C3AED"].map((c,i)=><Cell key={`plan-${i}`} fill={c} />)}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, fontSize: 12 }} />
            </RechartsPie>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {[["Starter","480","#CBD5E1"],["Pro","512","#2563EB"],["Enterprise","256","#7C3AED"]].map(([n,v,c])=>(
              <div key={n} className="flex items-center gap-2 text-xs">
                <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{backgroundColor:c}} />
                <span className="text-slate-600 flex-1">{n}</span>
                <span className="font-semibold text-slate-900">{v}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Business Management</h3>
          <div className="flex gap-2">
            <Btn variant="outline" size="sm" icon={<Filter className="w-3.5 h-3.5" />}>Filter</Btn>
            <Btn variant="outline" size="sm" icon={<Download className="w-3.5 h-3.5" />}>Export</Btn>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100">
                {["Business","Owner","Plan","Users","Revenue","Status","Joined"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {businesses.map(b => (
                <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5 font-medium text-slate-900">{b.name}</td>
                  <td className="px-5 py-3.5 text-slate-600">{b.owner}</td>
                  <td className="px-5 py-3.5">{statusBadge(b.plan)}</td>
                  <td className="px-5 py-3.5 text-slate-600">{b.users}</td>
                  <td className="px-5 py-3.5 font-medium text-slate-900">{fmt(b.revenue)}</td>
                  <td className="px-5 py-3.5">{statusBadge(b.status)}</td>
                  <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{b.joined}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ─── BUSINESS DASHBOARD ───────────────────────────────────────────────────────

function BusinessDashboard({ onNav }: { onNav: (p: AppPage) => void }) {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Today's Sales" value="₹48,200" sub="+18% vs yesterday" trend="up" icon={<TrendingUp className="w-5 h-5" />} color="bg-blue-50 text-blue-600" />
        <StatCard label="Monthly Revenue" value="₹8.9L" sub="+12.4% vs last month" trend="up" icon={<DollarSign className="w-5 h-5" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="Total Customers" value="342" sub="14 new this week" trend="up" icon={<Users className="w-5 h-5" />} color="bg-purple-50 text-purple-600" />
        <StatCard label="Low Stock Items" value="3" sub="Needs attention" trend="down" icon={<AlertTriangle className="w-5 h-5" />} color="bg-amber-50 text-amber-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-semibold text-slate-900">Sales vs Purchase</h3>
              <p className="text-xs text-slate-500 mt-0.5">Monthly comparison for 2024</p>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-blue-600 rounded inline-block" />Sales</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-emerald-500 rounded inline-block" />Purchase</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-violet-500 rounded inline-block" />Profit</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={salesData}>
              <defs>
                {[["salesGrad","#2563EB"],["purchGrad","#10B981"],["profGrad","#8B5CF6"]].map(([id,c])=>(
                  <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={c} stopOpacity={0.1} />
                    <stop offset="95%" stopColor={c} stopOpacity={0} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v/1000}K`} />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, ""]} />
              <Area type="monotone" dataKey="sales" stroke="#2563EB" strokeWidth={2} fill="url(#salesGrad)" name="Sales" />
              <Area type="monotone" dataKey="purchases" stroke="#10B981" strokeWidth={2} fill="url(#purchGrad)" name="Purchase" />
              <Area type="monotone" dataKey="profit" stroke="#8B5CF6" strokeWidth={2} fill="url(#profGrad)" name="Profit" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="font-semibold text-slate-900 mb-4 text-sm">Daily Sales (This Week)</h3>
            <ResponsiveContainer width="100%" height={120}>
              <BarChart data={dailySales} barSize={24}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="day" tick={{ fill: "#94A3B8", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, fontSize: 11 }} formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, "Sales"]} />
                <Bar dataKey="amount" fill="#2563EB" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card className="p-5">
            <h3 className="font-semibold text-slate-900 mb-4 text-sm">Sales by Category</h3>
            <div className="space-y-2.5">
              {pieData.map(d => (
                <div key={d.name}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600">{d.name}</span>
                    <span className="font-semibold text-slate-900">{d.value}%</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${d.value}%`, backgroundColor: d.color }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <h3 className="font-semibold text-slate-900">Recent Invoices</h3>
            <Btn variant="ghost" size="sm" onClick={() => onNav("pos")}>View All →</Btn>
          </div>
          <div className="divide-y divide-slate-50">
            {invoices.slice(0, 5).map(inv => (
              <div key={inv.id} className="flex items-center gap-4 px-5 py-3 hover:bg-slate-50 transition-colors">
                <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <FileText className="w-3.5 h-3.5 text-slate-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">{inv.customer}</p>
                  <p className="text-xs text-slate-500 font-mono">{inv.id}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-slate-900">{fmt(inv.total)}</p>
                  <p className="text-xs text-slate-400">{inv.date}</p>
                </div>
                {statusBadge(inv.status)}
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "New Invoice", icon: Receipt, color: "bg-blue-50 text-blue-600", action: () => onNav("pos") },
              { label: "Add Product", icon: Package, color: "bg-emerald-50 text-emerald-600", action: () => onNav("products") },
              { label: "Add Customer", icon: Users, color: "bg-purple-50 text-purple-600", action: () => onNav("customers") },
              { label: "Add Purchase", icon: ShoppingCart, color: "bg-amber-50 text-amber-600", action: () => onNav("purchase") },
              { label: "Add Expense", icon: Wallet, color: "bg-rose-50 text-rose-600", action: () => onNav("expenses") },
              { label: "View Reports", icon: BarChart3, color: "bg-slate-100 text-slate-600", action: () => onNav("reports") },
            ].map(q => (
              <button key={q.label} onClick={q.action} className="flex flex-col items-center gap-2 p-3 rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-sm transition-all group">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${q.color}`}>
                  <q.icon className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium text-slate-700 text-center leading-tight">{q.label}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── CUSTOMERS SCREEN ─────────────────────────────────────────────────────────

function CustomersScreen() {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [toast, setToast] = useState<{msg:string;type:"success"|"error"|"info"}|null>(null);
  const filtered = customers.filter(c => c.name.toLowerCase().includes(search.toLowerCase()) || c.city.toLowerCase().includes(search.toLowerCase()));

  const showToast = (msg: string, type: "success"|"error"|"info") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div className="space-y-5">
      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      {deleteId !== null && <ConfirmDialog message="This will permanently delete the customer and all their data." onConfirm={() => { setDeleteId(null); showToast("Customer deleted successfully", "success"); }} onCancel={() => setDeleteId(null)} />}
      {showModal && (
        <Modal title="Add New Customer" onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Input label="Business Name" placeholder="Raj Enterprises" />
              <Input label="Contact Person" placeholder="Rajesh Kumar" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Input label="Phone" placeholder="+91 98765 43210" icon={<Phone className="w-4 h-4" />} />
              <Input label="Email" placeholder="rajesh@raj.in" icon={<Mail className="w-4 h-4" />} />
            </div>
            <Input label="City" placeholder="Mumbai" icon={<MapPin className="w-4 h-4" />} />
            <Input label="GST Number" placeholder="27AAPCS0510Q1Z6" />
            <Input label="Opening Balance (₹)" placeholder="0" />
            <div className="flex gap-3 pt-2">
              <Btn variant="outline" onClick={() => setShowModal(false)} className="flex-1 justify-center">Cancel</Btn>
              <Btn variant="primary" onClick={() => { setShowModal(false); showToast("Customer added successfully", "success"); }} className="flex-1 justify-center">Save Customer</Btn>
            </div>
          </div>
        </Modal>
      )}

      <div className="flex items-center gap-3">
        <Input value={search} onChange={setSearch} placeholder="Search customers..." icon={<Search className="w-4 h-4" />} />
        <Btn variant="outline" size="md" icon={<Filter className="w-4 h-4" />}>Filter</Btn>
        <Btn variant="outline" size="md" icon={<Download className="w-4 h-4" />}>Export</Btn>
        <Btn variant="primary" size="md" onClick={() => setShowModal(true)} icon={<Plus className="w-4 h-4" />}>Add Customer</Btn>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[["342","Total Customers"],["₹1.8L","Total Receivable"],["₹10.5K","Total Payable"]].map(([v,l]) => (
          <Card key={l} className="p-4 text-center">
            <p className="text-xl font-bold text-slate-900">{v}</p>
            <p className="text-xs text-slate-500 mt-0.5">{l}</p>
          </Card>
        ))}
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100">
                {["Business","Contact","Phone","City","Balance","Status","Actions"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="py-8"><EmptyState icon={<Users className="w-6 h-6" />} title="No customers found" sub="Try adjusting your search query" /></td></tr>
              ) : filtered.map(c => (
                <tr key={c.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-5 py-4">
                    <p className="font-medium text-slate-900">{c.name}</p>
                    <p className="text-xs text-slate-400">{c.invoices} invoices</p>
                  </td>
                  <td className="px-5 py-4 text-slate-600">{c.contact}</td>
                  <td className="px-5 py-4 text-slate-600 font-mono text-xs">{c.phone}</td>
                  <td className="px-5 py-4 text-slate-600">{c.city}</td>
                  <td className="px-5 py-4">
                    <span className={`font-semibold font-mono text-sm ${c.balance > 0 ? "text-emerald-600" : c.balance < 0 ? "text-red-500" : "text-slate-500"}`}>
                      {c.balance > 0 ? "+" : ""}{fmt(Math.abs(c.balance))}
                    </span>
                    <p className="text-[10px] text-slate-400">{c.balance >= 0 ? "To Receive" : "To Pay"}</p>
                  </td>
                  <td className="px-5 py-4">{statusBadge(c.status)}</td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Btn variant="ghost" size="sm" icon={<Eye className="w-3.5 h-3.5" />} />
                      <Btn variant="ghost" size="sm" icon={<Edit2 className="w-3.5 h-3.5" />} />
                      <Btn variant="ghost" size="sm" onClick={() => setDeleteId(c.id)} icon={<Trash2 className="w-3.5 h-3.5 text-red-500" />} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-5 py-4 border-t border-slate-100">
          <p className="text-xs text-slate-500">Showing {filtered.length} of {customers.length} customers</p>
          <div className="flex items-center gap-1">
            {[1,2,3,"...",8].map((p,i) => (
              <button key={i} className={`w-8 h-8 text-xs rounded-lg ${p===1?"bg-blue-600 text-white":"text-slate-600 hover:bg-slate-100"}`}>{p}</button>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── SUPPLIERS SCREEN ─────────────────────────────────────────────────────────

function SuppliersScreen() {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const filtered = suppliers.filter(s => s.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-5">
      {showModal && (
        <Modal title="Add New Supplier" onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <Input label="Company Name" placeholder="TechVision Pvt Ltd" />
            <div className="grid grid-cols-2 gap-3">
              <Input label="Contact Person" placeholder="Arun Verma" />
              <Input label="Phone" placeholder="+91 98765 43210" icon={<Phone className="w-4 h-4" />} />
            </div>
            <Input label="Email" placeholder="arun@techvision.in" icon={<Mail className="w-4 h-4" />} />
            <div className="grid grid-cols-2 gap-3">
              <Input label="City" placeholder="Bangalore" />
              <Input label="GST Number" placeholder="29ABCDE1234F1Z5" />
            </div>
            <div className="flex gap-3 pt-2">
              <Btn variant="outline" onClick={() => setShowModal(false)} className="flex-1 justify-center">Cancel</Btn>
              <Btn variant="primary" onClick={() => setShowModal(false)} className="flex-1 justify-center">Save Supplier</Btn>
            </div>
          </div>
        </Modal>
      )}

      <div className="flex items-center gap-3">
        <Input value={search} onChange={setSearch} placeholder="Search suppliers..." icon={<Search className="w-4 h-4" />} />
        <Btn variant="outline" size="md" icon={<Filter className="w-4 h-4" />}>Filter</Btn>
        <Btn variant="primary" size="md" onClick={() => setShowModal(true)} icon={<Plus className="w-4 h-4" />}>Add Supplier</Btn>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100">
                {["Supplier","Contact","Phone","City","Balance Due","Status","Actions"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(s => (
                <tr key={s.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-5 py-4">
                    <p className="font-medium text-slate-900">{s.name}</p>
                    <p className="text-xs text-slate-400">{s.email}</p>
                  </td>
                  <td className="px-5 py-4 text-slate-600">{s.contact}</td>
                  <td className="px-5 py-4 text-slate-600 font-mono text-xs">{s.phone}</td>
                  <td className="px-5 py-4 text-slate-600">{s.city}</td>
                  <td className="px-5 py-4 font-semibold text-slate-900">{fmt(s.balance)}</td>
                  <td className="px-5 py-4">{statusBadge(s.status)}</td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Btn variant="ghost" size="sm" icon={<Eye className="w-3.5 h-3.5" />} />
                      <Btn variant="ghost" size="sm" icon={<Edit2 className="w-3.5 h-3.5" />} />
                      <Btn variant="ghost" size="sm" icon={<Trash2 className="w-3.5 h-3.5 text-red-500" />} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ─── PRODUCTS SCREEN ──────────────────────────────────────────────────────────

function ProductsScreen() {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [catFilter, setCatFilter] = useState("All");
  const cats = ["All", "Electronics", "Clothing", "Groceries", "Hardware"];

  const filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.includes(search);
    const matchCat = catFilter === "All" || p.category === catFilter;
    return matchSearch && matchCat;
  });

  return (
    <div className="space-y-5">
      {showModal && (
        <Modal title="Add New Product" onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <Input label="Product Name" placeholder="Samsung Galaxy Buds Pro" />
            <div className="grid grid-cols-2 gap-3">
              <Input label="SKU / Barcode" placeholder="EL-SGB-001" />
              <Select label="Category" value="Electronics" onChange={() => {}} options={cats.slice(1)} />
            </div>
            <Select label="Supplier" value="TechVision Pvt Ltd" onChange={() => {}} options={suppliers.map(s => s.name)} />
            <div className="grid grid-cols-3 gap-3">
              <Input label="Cost Price (₹)" placeholder="4200" />
              <Input label="Selling Price (₹)" placeholder="6999" />
              <Input label="GST %" placeholder="18" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Input label="Opening Stock" placeholder="0" />
              <Input label="Min. Stock Level" placeholder="10" />
            </div>
            <Select label="Unit" value="Piece" onChange={() => {}} options={["Piece","Kg","Litre","Box","Dozen","Metre"]} />
            <div className="flex gap-3 pt-2">
              <Btn variant="outline" onClick={() => setShowModal(false)} className="flex-1 justify-center">Cancel</Btn>
              <Btn variant="primary" onClick={() => setShowModal(false)} className="flex-1 justify-center">Save Product</Btn>
            </div>
          </div>
        </Modal>
      )}

      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex-1 min-w-48">
          <Input value={search} onChange={setSearch} placeholder="Search by name, SKU..." icon={<Search className="w-4 h-4" />} />
        </div>
        <div className="flex items-center gap-2">
          {cats.map(c => (
            <button key={c} onClick={() => setCatFilter(c)} className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${catFilter===c?"bg-blue-600 text-white":"bg-white border border-slate-200 text-slate-600 hover:border-blue-300"}`}>{c}</button>
          ))}
        </div>
        <Btn variant="outline" size="md" icon={<Upload className="w-4 h-4" />}>Import</Btn>
        <Btn variant="primary" size="md" onClick={() => setShowModal(true)} icon={<Plus className="w-4 h-4" />}>Add Product</Btn>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100">
                {["Product","SKU","Category","Supplier","Cost","Price","Stock","Status","Actions"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(p => {
                const lowStock = p.stock <= p.minStock;
                return (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-5 py-4 font-medium text-slate-900 max-w-[200px] truncate">{p.name}</td>
                    <td className="px-5 py-4 text-xs font-mono text-slate-500">{p.sku}</td>
                    <td className="px-5 py-4"><Badge label={p.category} variant="blue" /></td>
                    <td className="px-5 py-4 text-slate-600 text-xs truncate max-w-[140px]">{p.supplier}</td>
                    <td className="px-5 py-4 text-slate-600">{fmt(p.cost)}</td>
                    <td className="px-5 py-4 font-semibold text-slate-900">{fmt(p.price)}</td>
                    <td className="px-5 py-4">
                      <span className={`font-mono font-semibold text-sm ${p.stock === 0 ? "text-red-500" : lowStock ? "text-amber-600" : "text-slate-900"}`}>{p.stock}</span>
                      {lowStock && <div className="flex items-center gap-1 text-[10px] text-amber-600 mt-0.5"><AlertTriangle className="w-3 h-3" />Low Stock</div>}
                    </td>
                    <td className="px-5 py-4">{statusBadge(p.status)}</td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Btn variant="ghost" size="sm" icon={<Edit2 className="w-3.5 h-3.5" />} />
                        <Btn variant="ghost" size="sm" icon={<Trash2 className="w-3.5 h-3.5 text-red-500" />} />
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-5 py-3.5 border-t border-slate-100">
          <p className="text-xs text-slate-500">Showing {filtered.length} of {products.length} products</p>
          <div className="flex gap-1">
            {[1,2,3].map(p => <button key={p} className={`w-8 h-8 text-xs rounded-lg ${p===1?"bg-blue-600 text-white":"text-slate-600 hover:bg-slate-100"}`}>{p}</button>)}
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── POS / BILLING SCREEN ─────────────────────────────────────────────────────

function POSScreen() {
  const [cart, setCart] = useState<{product: typeof products[0]; qty: number; discount: number}[]>([]);
  const [customer, setCustomer] = useState("Walk-in Customer");
  const [paymentMode, setPaymentMode] = useState("Cash");
  const [search, setSearch] = useState("");
  const [gstRate] = useState(18);
  const [showInvoice, setShowInvoice] = useState(false);

  const filteredProducts = posProducts.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.includes(search));
  const addToCart = (p: typeof products[0]) => {
    setCart(c => {
      const ex = c.find(i => i.product.id === p.id);
      if (ex) return c.map(i => i.product.id === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...c, { product: p, qty: 1, discount: 0 }];
    });
  };
  const updateQty = (id: number, delta: number) => {
    setCart(c => c.map(i => i.product.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i).filter(i => i.qty > 0));
  };
  const removeItem = (id: number) => setCart(c => c.filter(i => i.product.id !== id));

  const subtotal = cart.reduce((s, i) => s + i.product.price * i.qty * (1 - i.discount / 100), 0);
  const gst = Math.round(subtotal * gstRate / 100);
  const total = subtotal + gst;

  if (showInvoice) {
    return (
      <div className="max-w-2xl mx-auto">
        <Btn variant="ghost" size="sm" onClick={() => setShowInvoice(false)} className="mb-4">← Back to Billing</Btn>
        <Card className="p-8">
          <div className="flex items-start justify-between mb-8">
            <div>
              <div className="flex items-center gap-2 mb-1"><div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center"><BarChart2 className="w-3.5 h-3.5 text-white" /></div><span className="font-bold text-slate-900">BillTrack Pro</span></div>
              <p className="text-xs text-slate-500">Sharma Traders, Mumbai</p>
              <p className="text-xs text-slate-500">GSTIN: 27AAPCS0510Q1Z6</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-blue-600 font-mono text-lg">INV-2024-1043</p>
              <p className="text-xs text-slate-500 mt-1">Date: {new Date().toLocaleDateString("en-IN")}</p>
              <Badge label="Paid" variant="green" />
            </div>
          </div>
          <div className="mb-6">
            <p className="text-xs text-slate-500 mb-1">Bill To:</p>
            <p className="font-semibold text-slate-900">{customer}</p>
          </div>
          <table className="w-full text-sm mb-5">
            <thead><tr className="border-b border-slate-200"><th className="text-left pb-2 text-xs text-slate-500">Item</th><th className="text-center pb-2 text-xs text-slate-500">Qty</th><th className="text-right pb-2 text-xs text-slate-500">Rate</th><th className="text-right pb-2 text-xs text-slate-500">Amount</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {cart.map(i => (
                <tr key={i.product.id}>
                  <td className="py-2.5 text-slate-800">{i.product.name}</td>
                  <td className="py-2.5 text-center text-slate-600">{i.qty}</td>
                  <td className="py-2.5 text-right font-mono text-slate-700">{fmt(i.product.price)}</td>
                  <td className="py-2.5 text-right font-mono font-medium text-slate-900">{fmt(i.product.price * i.qty)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex justify-end">
            <div className="w-52 space-y-2 text-sm">
              <div className="flex justify-between text-slate-600"><span>Subtotal</span><span className="font-mono">{fmt(subtotal)}</span></div>
              <div className="flex justify-between text-slate-600"><span>GST ({gstRate}%)</span><span className="font-mono">+{fmt(gst)}</span></div>
              <div className="flex justify-between font-bold text-slate-900 text-base border-t border-slate-200 pt-2 mt-2"><span>Total</span><span className="font-mono text-blue-600">{fmt(total)}</span></div>
            </div>
          </div>
          <div className="mt-6 pt-5 border-t border-slate-100 flex gap-3">
            <Btn variant="primary" icon={<Printer className="w-4 h-4" />}>Print Invoice</Btn>
            <Btn variant="outline" icon={<Download className="w-4 h-4" />}>Download PDF</Btn>
            <Btn variant="ghost" onClick={() => { setShowInvoice(false); setCart([]); }}>New Invoice</Btn>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex gap-5 h-[calc(100vh-160px)]">
      {/* Left: Products */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        <div className="flex items-center gap-3">
          <Input value={search} onChange={setSearch} placeholder="Search product or scan barcode..." icon={<ScanLine className="w-4 h-4" />} />
          <Btn variant="outline" size="md" icon={<ScanLine className="w-4 h-4" />}>Scan</Btn>
        </div>
        <div className="grid grid-cols-2 xl:grid-cols-3 gap-3 overflow-y-auto">
          {filteredProducts.map(p => (
            <button key={p.id} onClick={() => addToCart(p)} className="bg-white border border-slate-200 rounded-xl p-4 text-left hover:border-blue-400 hover:shadow-md transition-all group active:scale-[0.98]">
              <div className="w-full h-20 bg-slate-100 rounded-lg mb-3 flex items-center justify-center">
                <Package className="w-8 h-8 text-slate-400" />
              </div>
              <p className="text-xs font-semibold text-slate-900 mb-1 line-clamp-2 leading-snug">{p.name}</p>
              <p className="text-xs text-slate-400 font-mono mb-2">{p.sku}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-blue-600">{fmt(p.price)}</span>
                <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${p.stock < 10 ? "bg-amber-50 text-amber-600" : "bg-emerald-50 text-emerald-600"}`}>
                  Stock: {p.stock}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Right: Cart */}
      <Card className="w-80 flex-shrink-0 flex flex-col">
        <div className="p-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900 mb-3">Current Bill</h3>
          <Select label="Customer" value={customer} onChange={setCustomer} options={["Walk-in Customer", ...customers.map(c => c.name)]} />
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingCart className="w-10 h-10 text-slate-300 mb-3" />
              <p className="text-sm text-slate-500">Cart is empty</p>
              <p className="text-xs text-slate-400">Click products to add</p>
            </div>
          ) : cart.map(item => (
            <div key={item.product.id} className="bg-slate-50 rounded-xl p-3">
              <div className="flex items-start justify-between mb-2">
                <p className="text-xs font-semibold text-slate-900 flex-1 leading-snug">{item.product.name}</p>
                <button onClick={() => removeItem(item.product.id)} className="text-slate-400 hover:text-red-500 ml-2 flex-shrink-0"><X className="w-3.5 h-3.5" /></button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(item.product.id, -1)} className="w-6 h-6 bg-white border border-slate-200 rounded-md flex items-center justify-center hover:bg-slate-50"><Minus className="w-3 h-3" /></button>
                  <span className="text-sm font-bold text-slate-900 w-6 text-center">{item.qty}</span>
                  <button onClick={() => updateQty(item.product.id, 1)} className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center hover:bg-blue-700"><Plus className="w-3 h-3 text-white" /></button>
                </div>
                <span className="text-sm font-bold text-slate-900">{fmt(item.product.price * item.qty)}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-100 space-y-3">
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between text-slate-600"><span>Subtotal</span><span className="font-mono">{fmt(subtotal)}</span></div>
            <div className="flex justify-between text-slate-600"><span>GST ({gstRate}%)</span><span className="font-mono">+{fmt(gst)}</span></div>
            <div className="flex justify-between font-bold text-slate-900 text-base border-t border-slate-200 pt-1.5 mt-1.5">
              <span>Total</span><span className="font-mono text-blue-600">{fmt(total)}</span>
            </div>
          </div>
          <Select label="Payment Mode" value={paymentMode} onChange={setPaymentMode} options={["Cash","UPI","Card","Bank Transfer","Credit"]} />
          <Btn
            variant="success"
            onClick={() => cart.length > 0 && setShowInvoice(true)}
            disabled={cart.length === 0}
            className="w-full justify-center"
            icon={<Receipt className="w-4 h-4" />}
          >
            Generate Invoice
          </Btn>
        </div>
      </Card>
    </div>
  );
}

// ─── PURCHASE SCREEN ──────────────────────────────────────────────────────────

function PurchaseScreen() {
  const [activeTab, setActiveTab] = useState<"entry"|"history">("history");
  const [supplier, setSupplier] = useState(suppliers[0].name);
  const [items, setItems] = useState([{ product: "", qty: 1, rate: 0 }]);

  return (
    <div className="space-y-5">
      <div className="flex border-b border-slate-200 gap-6">
        {[["entry","New Purchase"],["history","Purchase History"]].map(([k,l]) => (
          <button key={k} onClick={() => setActiveTab(k as any)}
            className={`pb-3 text-sm font-medium transition-all border-b-2 -mb-px ${activeTab===k?"border-blue-600 text-blue-600":"border-transparent text-slate-500 hover:text-slate-700"}`}>
            {l}
          </button>
        ))}
      </div>

      {activeTab === "entry" ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-5">
            <Card className="p-5">
              <h3 className="font-semibold text-slate-900 mb-4">Purchase Details</h3>
              <div className="grid grid-cols-2 gap-4">
                <Select label="Supplier" value={supplier} onChange={setSupplier} options={suppliers.map(s => s.name)} />
                <Input label="Invoice No." placeholder="SUPP-INV-001" />
                <Input label="Purchase Date" type="date" value={new Date().toISOString().slice(0,10)} />
                <Input label="Due Date" type="date" />
              </div>
            </Card>

            <Card className="p-5">
              <h3 className="font-semibold text-slate-900 mb-4">Products</h3>
              <table className="w-full text-sm mb-3">
                <thead><tr className="border-b border-slate-100"><th className="text-left pb-2 text-xs text-slate-500">Product</th><th className="text-center pb-2 text-xs text-slate-500 w-20">Qty</th><th className="text-right pb-2 text-xs text-slate-500 w-28">Rate</th><th className="text-right pb-2 text-xs text-slate-500 w-28">Amount</th></tr></thead>
                <tbody>
                  {items.map((item, i) => (
                    <tr key={i} className="border-b border-slate-50">
                      <td className="py-2">
                        <select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-blue-500">
                          <option>Select Product</option>
                          {products.map(p => <option key={p.id}>{p.name}</option>)}
                        </select>
                      </td>
                      <td className="py-2 px-2"><input type="number" defaultValue={1} min={1} className="w-full text-center border border-slate-200 rounded-lg px-2 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500" /></td>
                      <td className="py-2 px-2"><input type="number" defaultValue={0} className="w-full text-right border border-slate-200 rounded-lg px-2 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500" /></td>
                      <td className="py-2 text-right font-medium text-slate-900">₹0</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <Btn variant="outline" size="sm" onClick={() => setItems(it => [...it, { product: "", qty: 1, rate: 0 }])} icon={<Plus className="w-3.5 h-3.5" />}>Add Row</Btn>
            </Card>
          </div>

          <div className="space-y-4">
            <Card className="p-5">
              <h3 className="font-semibold text-slate-900 mb-4">Payment Summary</h3>
              <div className="space-y-3">
                {[["Subtotal","₹0"],["GST (18%)","+ ₹0"],["Discount","- ₹0"],["Total","₹0"]].map(([l,v],i) => (
                  <div key={l} className={`flex justify-between text-sm ${i===3?"font-bold text-slate-900 border-t border-slate-200 pt-3":"text-slate-600"}`}>
                    <span>{l}</span><span className="font-mono">{v}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 space-y-3">
                <Select label="Payment Status" value="Unpaid" onChange={() => {}} options={["Paid","Unpaid","Partial"]} />
                <Btn variant="primary" className="w-full justify-center" icon={<Check className="w-4 h-4" />}>Save Purchase</Btn>
              </div>
            </Card>
            <Card className="p-4">
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Notes</h4>
              <textarea placeholder="Add notes or terms..." rows={3} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
            </Card>
          </div>
        </div>
      ) : (
        <Card>
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <Input placeholder="Search purchases..." icon={<Search className="w-4 h-4" />} />
            <div className="flex gap-2 ml-3">
              <Btn variant="outline" size="sm" icon={<Filter className="w-3.5 h-3.5" />}>Filter</Btn>
              <Btn variant="outline" size="sm" icon={<Download className="w-3.5 h-3.5" />}>Export</Btn>
            </div>
          </div>
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-100">{["PO No.","Supplier","Date","Items","Total","Status"].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-50">
              {[
                ["PO-2024-038","TechVision Pvt Ltd","2024-08-10",5,"₹1,24,800","Received"],
                ["PO-2024-037","FabWorld Exports","2024-08-07",12,"₹48,200","Received"],
                ["PO-2024-036","AgriLink Wholesale","2024-08-03",8,"₹32,600","Pending"],
              ].map(([id,sup,date,items,total,status]) => (
                <tr key={id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5 font-mono text-xs text-blue-600">{id}</td>
                  <td className="px-5 py-3.5 text-slate-900">{sup}</td>
                  <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{date}</td>
                  <td className="px-5 py-3.5 text-slate-600">{items}</td>
                  <td className="px-5 py-3.5 font-semibold text-slate-900">{total}</td>
                  <td className="px-5 py-3.5">{statusBadge(status as string)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}

// ─── INVENTORY SCREEN ─────────────────────────────────────────────────────────

function InventoryScreen() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Products" value="231" sub="Across 4 categories" trend="neutral" icon={<Package className="w-5 h-5" />} color="bg-blue-50 text-blue-600" />
        <StatCard label="Total Stock Value" value="₹24.8L" sub="+6.2% this month" trend="up" icon={<DollarSign className="w-5 h-5" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="Low Stock Items" value="3" sub="Action required" trend="down" icon={<AlertTriangle className="w-5 h-5" />} color="bg-amber-50 text-amber-600" />
        <StatCard label="Out of Stock" value="1" sub="Reorder pending" trend="down" icon={<XCircle className="w-5 h-5" />} color="bg-red-50 text-red-500" />
      </div>

      <Card className="p-5">
        <h3 className="font-semibold text-slate-900 mb-1">Low Stock Alerts</h3>
        <p className="text-xs text-slate-500 mb-4">Items that need immediate reordering</p>
        <div className="space-y-3">
          {products.filter(p => p.stock <= p.minStock).map(p => (
            <div key={p.id} className={`flex items-center gap-4 p-4 rounded-xl border ${p.stock === 0 ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"}`}>
              <AlertTriangle className={`w-5 h-5 flex-shrink-0 ${p.stock === 0 ? "text-red-500" : "text-amber-500"}`} />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-900">{p.name}</p>
                <p className="text-xs text-slate-500 font-mono">{p.sku}</p>
              </div>
              <div className="text-right">
                <p className={`text-sm font-bold ${p.stock === 0 ? "text-red-500" : "text-amber-600"}`}>
                  {p.stock === 0 ? "Out of Stock" : `${p.stock} left`}
                </p>
                <p className="text-xs text-slate-500">Min: {p.minStock}</p>
              </div>
              <Btn variant={p.stock === 0 ? "danger" : "outline"} size="sm" icon={<ShoppingCart className="w-3.5 h-3.5" />}>
                Reorder
              </Btn>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Current Stock</h3>
          <div className="flex gap-2">
            <Btn variant="outline" size="sm" icon={<RefreshCw className="w-3.5 h-3.5" />}>Adjust Stock</Btn>
            <Btn variant="outline" size="sm" icon={<Download className="w-3.5 h-3.5" />}>Export</Btn>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-100">{["Product","Category","In Stock","Min Level","Value","Status"].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-slate-50">
            {products.map(p => (
              <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-5 py-3.5">
                  <p className="font-medium text-slate-900">{p.name}</p>
                  <p className="text-xs text-slate-400 font-mono">{p.sku}</p>
                </td>
                <td className="px-5 py-3.5"><Badge label={p.category} variant="blue" /></td>
                <td className="px-5 py-3.5">
                  <div className="flex items-center gap-2">
                    <span className={`font-bold font-mono ${p.stock===0?"text-red-500":p.stock<=p.minStock?"text-amber-600":"text-slate-900"}`}>{p.stock}</span>
                    <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${Math.min(100, (p.stock/50)*100)}%`, backgroundColor: p.stock===0?"#EF4444":p.stock<=p.minStock?"#F59E0B":"#10B981" }} />
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3.5 text-slate-600 font-mono">{p.minStock}</td>
                <td className="px-5 py-3.5 font-medium text-slate-900">{fmt(p.price * p.stock)}</td>
                <td className="px-5 py-3.5">{statusBadge(p.stock===0?"Inactive":p.status)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ─── REPORTS SCREEN ───────────────────────────────────────────────────────────

function ReportsScreen() {
  const [activeReport, setActiveReport] = useState("sales");
  const reportTypes = [
    { key: "sales", label: "Sales Report", icon: TrendingUp },
    { key: "purchase", label: "Purchase Report", icon: ShoppingCart },
    { key: "pl", label: "Profit & Loss", icon: BarChart3 },
    { key: "gst", label: "GST Report", icon: Percent },
    { key: "inventory", label: "Inventory Report", icon: Package },
  ];

  return (
    <div className="space-y-5">
      <div className="flex gap-2 flex-wrap">
        {reportTypes.map(r => (
          <button key={r.key} onClick={() => setActiveReport(r.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeReport===r.key?"bg-blue-600 text-white shadow-sm":"bg-white border border-slate-200 text-slate-600 hover:border-blue-300"}`}>
            <r.icon className="w-4 h-4" />{r.label}
          </button>
        ))}
        <div className="ml-auto flex gap-2">
          <Btn variant="outline" size="md" icon={<Download className="w-4 h-4" />}>Export Excel</Btn>
          <Btn variant="outline" size="md" icon={<Printer className="w-4 h-4" />}>Print PDF</Btn>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {[["₹8.9L","Total Revenue","+12%","up"],["₹5.2L","Total Expenses","+3%","up"],["₹3.7L","Net Profit","+24%","up"],["41.6%","Profit Margin","+5%","up"]].map(([v,l,s,t])=>(
          <Card key={l} className="p-4">
            <p className={`text-xl font-bold ${l.includes("Profit")?"text-emerald-600":"l"==="Profit Margin"?"text-purple-600":"text-slate-900"}`}>{v}</p>
            <p className="text-xs text-slate-500 mt-0.5 mb-2">{l}</p>
            <span className={`text-xs font-medium flex items-center gap-1 ${t==="up"?"text-emerald-600":"text-red-500"}`}><ArrowUpRight className="w-3 h-3" />{s} this month</span>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card className="p-5">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-slate-900">Monthly Revenue Trend</h3>
            <div className="flex gap-2">
              {["2024","2023"].map(y => <button key={y} className={`text-xs px-2.5 py-1 rounded-lg ${y==="2024"?"bg-blue-600 text-white":"text-slate-500 hover:bg-slate-100"}`}>{y}</button>)}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={salesData}>
              <defs>
                <linearGradient id="repSales" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v/1000}K`} />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, ""]} />
              <Area type="monotone" dataKey="sales" stroke="#2563EB" strokeWidth={2.5} fill="url(#repSales)" name="Sales" />
              <Area type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={2} fill="none" name="Profit" strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 mb-5">Expenses Breakdown</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={[{name:"Rent",v:45000},{name:"Salary",v:125000},{name:"Util.",v:8200},{name:"Marketing",v:15000},{name:"Logistics",v:12400}]} barSize={32}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="name" tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v/1000}K`} />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, fontSize: 12 }} formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, ""]} />
              <Bar dataKey="v" fill="#6366F1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {expenses.slice(0,4).map(e => (
              <div key={e.id} className="flex items-center justify-between text-xs">
                <span className="text-slate-600">{e.category}</span>
                <div className="flex items-center gap-3">
                  <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${(e.amount / 125000) * 100}%` }} />
                  </div>
                  <span className="font-mono font-medium text-slate-900 w-20 text-right">{fmt(e.amount)}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-semibold text-slate-900">Sales Details</h3>
          <div className="flex gap-2">
            <Input placeholder="From date" type="date" />
            <Input placeholder="To date" type="date" />
            <Btn variant="primary" size="sm">Apply</Btn>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-100">{["Invoice","Customer","Date","Amount","GST","Total","Status"].map(h=><th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-slate-50">
            {invoices.map(inv=>(
              <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-5 py-3.5 font-mono text-xs text-blue-600">{inv.id}</td>
                <td className="px-5 py-3.5 font-medium text-slate-900">{inv.customer}</td>
                <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{inv.date}</td>
                <td className="px-5 py-3.5 text-slate-900">{fmt(inv.amount)}</td>
                <td className="px-5 py-3.5 text-slate-600">{fmt(inv.gst)}</td>
                <td className="px-5 py-3.5 font-semibold text-slate-900">{fmt(inv.total)}</td>
                <td className="px-5 py-3.5">{statusBadge(inv.status)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ─── EXPENSES SCREEN ──────────────────────────────────────────────────────────

function ExpensesScreen() {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="space-y-5">
      {showModal && (
        <Modal title="Add Expense" onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <Select label="Category" value="Rent" onChange={() => {}} options={["Rent","Utilities","Salaries","Marketing","Logistics","Maintenance","Other"]} />
            <Input label="Description" placeholder="August rent payment" />
            <div className="grid grid-cols-2 gap-3">
              <Input label="Amount (₹)" placeholder="45000" />
              <Input label="Date" type="date" value={new Date().toISOString().slice(0,10)} />
            </div>
            <Select label="Payment Mode" value="Bank Transfer" onChange={() => {}} options={["Cash","Bank Transfer","UPI","Credit Card","Cheque"]} />
            <Input label="Reference / Receipt No." placeholder="REF-001" />
            <div className="flex gap-3 pt-2">
              <Btn variant="outline" onClick={() => setShowModal(false)} className="flex-1 justify-center">Cancel</Btn>
              <Btn variant="primary" onClick={() => setShowModal(false)} className="flex-1 justify-center">Save Expense</Btn>
            </div>
          </div>
        </Modal>
      )}

      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Total Expenses (Aug)" value="₹2.06L" sub="+8% vs last month" trend="up" icon={<Wallet className="w-5 h-5" />} color="bg-red-50 text-red-500" />
        <StatCard label="Largest Expense" value="Salaries" sub="₹1,25,000 (60.7%)" trend="neutral" icon={<Users className="w-5 h-5" />} color="bg-purple-50 text-purple-600" />
        <StatCard label="Pending Payments" value="₹12,400" sub="1 item pending" trend="neutral" icon={<Clock className="w-5 h-5" />} color="bg-amber-50 text-amber-600" />
      </div>

      <Card>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Expense History</h3>
          <Btn variant="primary" size="md" onClick={() => setShowModal(true)} icon={<Plus className="w-4 h-4" />}>Add Expense</Btn>
        </div>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-100">{["Category","Description","Date","Amount","Mode","Status"].map(h=><th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-slate-50">
            {expenses.map(e=>(
              <tr key={e.id} className="hover:bg-slate-50 transition-colors group">
                <td className="px-5 py-3.5"><Badge label={e.category} variant="purple" /></td>
                <td className="px-5 py-3.5 text-slate-900">{e.description}</td>
                <td className="px-5 py-3.5 text-slate-500 text-xs font-mono">{e.date}</td>
                <td className="px-5 py-3.5 font-semibold text-slate-900">{fmt(e.amount)}</td>
                <td className="px-5 py-3.5 text-slate-600">{e.paymentMode}</td>
                <td className="px-5 py-3.5">{statusBadge(e.status)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ─── USER MANAGEMENT ──────────────────────────────────────────────────────────

function UsersScreen() {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="space-y-5">
      {showModal && (
        <Modal title="Add Employee" onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Input label="Full Name" placeholder="Priya Sharma" />
              <Input label="Email" placeholder="priya@business.in" icon={<Mail className="w-4 h-4" />} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Select label="Role" value="Cashier" onChange={() => {}} options={["Owner","Manager","Cashier","Accountant"]} />
              <Input label="Department" placeholder="Sales" />
            </div>
            <Input label="Phone" placeholder="+91 98765 43210" icon={<Phone className="w-4 h-4" />} />
            <Input label="Temporary Password" type="password" placeholder="Min. 8 characters" icon={<Lock className="w-4 h-4" />} />
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Permissions</p>
              <div className="grid grid-cols-2 gap-2">
                {["View Dashboard","Create Invoices","Manage Products","View Reports","Manage Customers","Access Settings"].map(p=>(
                  <label key={p} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input type="checkbox" className="accent-blue-600 rounded" defaultChecked={p!=="Access Settings"} />{p}
                  </label>
                ))}
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Btn variant="outline" onClick={() => setShowModal(false)} className="flex-1 justify-center">Cancel</Btn>
              <Btn variant="primary" onClick={() => setShowModal(false)} className="flex-1 justify-center">Add Employee</Btn>
            </div>
          </div>
        </Modal>
      )}

      <div className="flex justify-end">
        <Btn variant="primary" size="md" onClick={() => setShowModal(true)} icon={<Plus className="w-4 h-4" />}>Add Employee</Btn>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {[["4","Total Users"],["3","Active"],["1","Inactive"],["3","Roles Used"]].map(([v,l])=>(
          <Card key={l} className="p-4 text-center">
            <p className="text-xl font-bold text-slate-900">{v}</p>
            <p className="text-xs text-slate-500 mt-0.5">{l}</p>
          </Card>
        ))}
      </div>

      <Card>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-100">{["Employee","Email","Role","Department","Last Active","Status","Actions"].map(h=><th key={h} className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-slate-50">
            {employees.map(e=>(
              <tr key={e.id} className="hover:bg-slate-50 transition-colors group">
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-bold text-blue-600">{e.name.split(" ").map(n=>n[0]).join("")}</span>
                    </div>
                    <span className="font-medium text-slate-900">{e.name}</span>
                  </div>
                </td>
                <td className="px-5 py-4 text-slate-500 text-xs">{e.email}</td>
                <td className="px-5 py-4">{statusBadge(e.role==="Manager"?"Pro":e.role==="Accountant"?"blue":"gray" as any) || <Badge label={e.role} variant={e.role==="Manager"?"purple":e.role==="Accountant"?"blue":"gray"} />}</td>
                <td className="px-5 py-4 text-slate-600">{e.department}</td>
                <td className="px-5 py-4 text-slate-500 text-xs">{e.lastActive}</td>
                <td className="px-5 py-4">{statusBadge(e.status)}</td>
                <td className="px-5 py-4">
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Btn variant="ghost" size="sm" icon={<Edit2 className="w-3.5 h-3.5" />} />
                    <Btn variant="ghost" size="sm" icon={<Trash2 className="w-3.5 h-3.5 text-red-500" />} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ─── SETTINGS SCREEN ──────────────────────────────────────────────────────────

function SettingsScreen() {
  const [activeTab, setActiveTab] = useState("business");
  const tabs = [
    { key: "business", label: "Business Profile", icon: Building2 },
    { key: "gst", label: "GST & Tax", icon: Percent },
    { key: "invoice", label: "Invoice Settings", icon: Receipt },
    { key: "users", label: "Security", icon: Lock },
  ];

  return (
    <div className="flex gap-6">
      <Card className="w-48 p-3 h-fit flex-shrink-0">
        <nav className="space-y-0.5">
          {tabs.map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${activeTab===t.key?"bg-blue-50 text-blue-700":"text-slate-600 hover:bg-slate-100"}`}>
              <t.icon className="w-4 h-4 flex-shrink-0" />{t.label}
            </button>
          ))}
        </nav>
      </Card>

      <div className="flex-1 space-y-5">
        {activeTab === "business" && (
          <Card className="p-6">
            <h3 className="font-semibold text-slate-900 mb-5">Business Information</h3>
            <div className="flex items-start gap-6 mb-6">
              <div className="w-20 h-20 bg-slate-100 rounded-xl flex items-center justify-center border-2 border-dashed border-slate-300 cursor-pointer hover:bg-slate-50 flex-shrink-0">
                <div className="text-center"><Upload className="w-5 h-5 text-slate-400 mx-auto mb-1" /><p className="text-[10px] text-slate-400">Upload Logo</p></div>
              </div>
              <div className="flex-1 grid grid-cols-2 gap-4">
                <Input label="Business Name" value="Sharma Traders" />
                <Input label="Owner Name" value="Vikram Sharma" />
                <Input label="Phone" value="+91 98765 43210" icon={<Phone className="w-4 h-4" />} />
                <Input label="Email" value="contact@sharmatraders.in" icon={<Mail className="w-4 h-4" />} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="col-span-2"><Input label="Address" value="Shop No. 14, Sadar Bazaar, Nagpur" icon={<MapPin className="w-4 h-4" />} /></div>
              <Input label="City" value="Nagpur" />
              <Input label="State" value="Maharashtra" />
              <Input label="Pincode" value="440001" />
              <Select label="Country" value="India" onChange={() => {}} options={["India"]} />
            </div>
            <Btn variant="primary" icon={<Check className="w-4 h-4" />}>Save Changes</Btn>
          </Card>
        )}
        {activeTab === "gst" && (
          <Card className="p-6">
            <h3 className="font-semibold text-slate-900 mb-5">GST & Tax Settings</h3>
            <div className="grid grid-cols-2 gap-4">
              <Input label="GSTIN" value="27AAPCS0510Q1Z6" />
              <Select label="GST Registration Type" value="Regular" onChange={() => {}} options={["Regular","Composition","Unregistered"]} />
              <Input label="PAN Number" value="AAPCS0510Q" />
              <Select label="Default GST Rate %" value="18" onChange={() => {}} options={["0","5","12","18","28"]} />
            </div>
            <div className="mt-4 space-y-3">
              {[["Enable IGST","Apply IGST for inter-state transactions"],["Enable Cess","Apply additional cess on specific products"],["Reverse Charge","Enable reverse charge mechanism"]].map(([l,d])=>(
                <div key={l} className="flex items-start justify-between py-3 border-b border-slate-100">
                  <div><p className="text-sm font-medium text-slate-900">{l}</p><p className="text-xs text-slate-500">{d}</p></div>
                  <button className="w-10 h-6 bg-blue-600 rounded-full relative flex-shrink-0 ml-4">
                    <span className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow" />
                  </button>
                </div>
              ))}
            </div>
            <Btn variant="primary" className="mt-5" icon={<Check className="w-4 h-4" />}>Save GST Settings</Btn>
          </Card>
        )}
        {activeTab === "invoice" && (
          <Card className="p-6">
            <h3 className="font-semibold text-slate-900 mb-5">Invoice Settings</h3>
            <div className="grid grid-cols-2 gap-4">
              <Input label="Invoice Prefix" value="INV-" />
              <Input label="Starting Number" value="1001" />
              <Input label="Invoice Footer" value="Thank you for your business!" />
              <Select label="Default Payment Terms" value="Net 15" onChange={() => {}} options={["Immediate","Net 7","Net 15","Net 30","Net 60"]} />
            </div>
            <div className="mt-4">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Invoice Template</p>
              <div className="grid grid-cols-3 gap-3">
                {["Classic","Modern","Minimal"].map((t,i)=>(
                  <button key={t} className={`border-2 rounded-xl p-3 text-center transition-all ${i===1?"border-blue-500 bg-blue-50":"border-slate-200 hover:border-slate-300"}`}>
                    <div className="h-16 bg-slate-100 rounded-lg mb-2" />
                    <p className="text-xs font-medium text-slate-700">{t}</p>
                  </button>
                ))}
              </div>
            </div>
            <Btn variant="primary" className="mt-5" icon={<Check className="w-4 h-4" />}>Save Invoice Settings</Btn>
          </Card>
        )}
        {activeTab === "users" && (
          <Card className="p-6">
            <h3 className="font-semibold text-slate-900 mb-5">Security Settings</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <Input label="Current Password" type="password" placeholder="••••••••" icon={<Lock className="w-4 h-4" />} />
                <Input label="New Password" type="password" placeholder="Min. 8 characters" icon={<Lock className="w-4 h-4" />} />
                <Input label="Confirm New Password" type="password" placeholder="Re-enter new password" icon={<Lock className="w-4 h-4" />} />
              </div>
              <div className="space-y-3 pt-2">
                {[["Two-Factor Authentication","Require OTP on login"],["Session Timeout","Auto-logout after 30 minutes of inactivity"],["Login Notifications","Send email on new login"]].map(([l,d])=>(
                  <div key={l} className="flex items-start justify-between py-3 border-b border-slate-100">
                    <div><p className="text-sm font-medium text-slate-900">{l}</p><p className="text-xs text-slate-500">{d}</p></div>
                    <button className="w-10 h-6 bg-slate-200 rounded-full relative flex-shrink-0 ml-4">
                      <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow" />
                    </button>
                  </div>
                ))}
              </div>
              <Btn variant="primary" icon={<Lock className="w-4 h-4" />}>Update Password</Btn>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

// ─── NOTIFICATIONS SCREEN ─────────────────────────────────────────────────────

function NotificationsScreen() {
  const typeIcon = { warning: <AlertTriangle className="w-4 h-4 text-amber-500" />, error: <XCircle className="w-4 h-4 text-red-500" />, success: <CheckCircle className="w-4 h-4 text-emerald-500" />, info: <Info className="w-4 h-4 text-blue-500" /> };
  const typeBg = { warning: "bg-amber-50 border-amber-200", error: "bg-red-50 border-red-200", success: "bg-emerald-50 border-emerald-200", info: "bg-blue-50 border-blue-200" };

  return (
    <div className="max-w-3xl space-y-3">
      <div className="flex justify-between items-center mb-5">
        <p className="text-sm text-slate-500">{notifications.filter(n => !n.read).length} unread notifications</p>
        <Btn variant="ghost" size="sm">Mark all as read</Btn>
      </div>
      {notifications.map(n => (
        <div key={n.id} className={`flex gap-4 p-4 rounded-xl border transition-all hover:shadow-sm ${n.read ? "bg-white border-slate-200 opacity-70" : typeBg[n.type]}`}>
          <div className="flex-shrink-0 mt-0.5">{typeIcon[n.type]}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-4">
              <p className="text-sm font-semibold text-slate-900">{n.title}</p>
              <span className="text-xs text-slate-400 flex-shrink-0">{n.time}</span>
            </div>
            <p className="text-sm text-slate-600 mt-0.5">{n.message}</p>
          </div>
          {!n.read && <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5 flex-shrink-0" />}
        </div>
      ))}
    </div>
  );
}

// ─── PROFILE SCREEN ───────────────────────────────────────────────────────────

function ProfileScreen() {
  return (
    <div className="max-w-2xl space-y-5">
      <Card className="p-6">
        <div className="flex items-start gap-5 mb-6">
          <div className="relative">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center">
              <span className="text-xl font-bold text-white">AU</span>
            </div>
            <button className="absolute -bottom-1 -right-1 w-6 h-6 bg-white border border-slate-200 rounded-full flex items-center justify-center shadow-sm hover:bg-slate-50">
              <Edit2 className="w-3 h-3 text-slate-600" />
            </button>
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-lg">Admin User</h3>
            <p className="text-sm text-slate-500">Business Owner · Sharma Traders</p>
            <Badge label="Pro Plan" variant="blue" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Input label="First Name" value="Admin" />
          <Input label="Last Name" value="User" />
          <Input label="Email" value="admin@business.in" icon={<Mail className="w-4 h-4" />} />
          <Input label="Phone" value="+91 98765 43210" icon={<Phone className="w-4 h-4" />} />
        </div>
        <Btn variant="primary" className="mt-5" icon={<Check className="w-4 h-4" />}>Update Profile</Btn>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-slate-900 mb-4">Account Summary</h3>
        <div className="grid grid-cols-3 gap-4">
          {[["342","Customers"],["7","Products Active"],["1,042","Invoices"]].map(([v,l])=>(
            <div key={l} className="bg-slate-50 rounded-xl p-4 text-center">
              <p className="text-xl font-bold text-blue-600">{v}</p>
              <p className="text-xs text-slate-500 mt-0.5">{l}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─── APP SHELL ────────────────────────────────────────────────────────────────

function AppShell({ role, onLogout }: { role: AppRole; onLogout: () => void }) {
  const [page, setPage] = useState<AppPage>(role === "superadmin" ? "super-dashboard" : "dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const unread = notifications.filter(n => !n.read).length;

  const nav = useCallback((p: AppPage) => setPage(p), []);

  const renderPage = () => {
    switch (page) {
      case "super-dashboard": return <SuperAdminDashboard />;
      case "dashboard": return <BusinessDashboard onNav={nav} />;
      case "customers": return <CustomersScreen />;
      case "suppliers": return <SuppliersScreen />;
      case "products": return <ProductsScreen />;
      case "pos": return <POSScreen />;
      case "purchase": return <PurchaseScreen />;
      case "inventory": return <InventoryScreen />;
      case "reports": return <ReportsScreen />;
      case "expenses": return <ExpensesScreen />;
      case "users": return <UsersScreen />;
      case "settings": return <SettingsScreen />;
      case "notifications": return <NotificationsScreen />;
      case "profile": return <ProfileScreen />;
      default: return <BusinessDashboard onNav={nav} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      <Sidebar page={page} onNav={nav} role={role} collapsed={collapsed} onToggle={() => setCollapsed(v => !v)} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Topbar page={page} onLogout={onLogout} onNav={nav} role={role} notifCount={unread} />
        <main className="flex-1 overflow-y-auto p-6">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}

// ─── ROOT ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<AppView>("landing");
  const [role, setRole] = useState<AppRole>("owner");

  const handleLogin = (r: AppRole) => { setRole(r); setView("app"); };
  const handleLogout = () => setView("landing");
  const navAuth = (v: AppView) => setView(v);

  if (view === "landing") return <LandingPage onNav={navAuth} />;
  if (view === "login" || view === "register" || view === "forgot") {
    return <AuthScreen view={view} onNav={navAuth} onLogin={handleLogin} />;
  }
  if (view === "app") return <AppShell role={role} onLogout={handleLogout} />;
  return null;
}
